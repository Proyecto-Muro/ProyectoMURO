#GIMME ALL THE PROBLEEEEMSSSS
from aopsTeX import CollectProblems
List=[
    ['OMM', 3344],
    ['OIM', 3229],
    ['IMO', 3222],
    ['ISL', 3223],
    ['RMM', 3238],
    ['APMO', 3226]
    ]
for i in List:
    CollectProblems(i[1],i[0])
